package com.omp.freeboard.domain;

public class CommentDM {
 
	
	   
}
