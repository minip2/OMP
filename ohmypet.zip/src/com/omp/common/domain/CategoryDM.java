package com.omp.common.domain;

public class CategoryDM {
	private int groupVal;
	private int categoryVal;
	private String categoryName;
	
	
	public int getGroupVal() {
		return groupVal;
	}
	public void setGroupVal(int groupVal) {
		this.groupVal = groupVal;
	}
	public int getCategoryVal() {
		return categoryVal;
	}
	public void setCategoryVal(int categoryVal) {
		this.categoryVal = categoryVal;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	
}
