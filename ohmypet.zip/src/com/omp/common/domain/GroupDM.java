package com.omp.common.domain;

public class GroupDM {
	private int groupVal;
	private String groupName;
	
	public int getGroupVal() {
		return groupVal;
	}
	public void setGroupVal(int groupVal) {
		this.groupVal = groupVal;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	

}
