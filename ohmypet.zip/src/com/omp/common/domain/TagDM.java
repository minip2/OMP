package com.omp.common.domain;

public class TagDM {

}
